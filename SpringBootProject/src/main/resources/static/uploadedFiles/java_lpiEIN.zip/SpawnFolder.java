//*******************************************************************
// NOTE: please read the 'More Info' tab to the right for shortcuts.
//*******************************************************************

import java.lang.Math; // headers MUST be above the first class
import java.io.File;

public class SpawnFolder{
  
  	public static void main(String []args){
      String path = "d:\\school\\";
      String folder_name = "";
      for(int i = 0; i < Integer.parseInt(args[0]); i++){
        for(int j = 0; j < 10; j++){
        	folder_name += Math.random()*10;
        }
        try{
      		new File(path+folder_name).mkdir();  
        }catch(Exception e){
         	System.err.println("Error! Folder wasn't created"); 
        }
        folder_name = "";
      }
  	} 
}